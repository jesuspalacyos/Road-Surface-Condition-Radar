"""Synthetic geometry and peak-selection tests; does not test live hardware."""
import unittest
import csv
import json
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from ice_radar import beat_frequency_mhz, roi_peak, sampling_rate_hz, config, ROOT, App


class SpectrumTests(unittest.TestCase):
    def setUp(self):
        self.lines, self.n, self.dr, _ = config(ROOT/'road_profile.cfg')

    def test_beat_axis(self):
        fs = sampling_rate_hz(self.lines)
        self.assertEqual(fs, 12_499_000)
        f = beat_frequency_mhz(self.n, fs)
        self.assertEqual(len(f), 256)
        self.assertAlmostEqual(f[1], fs/256/1e6)
        self.assertAlmostEqual(f[10]*1e6*299792458/(2*30e12), 10*self.dr)

    def test_no_reference_strongest_bin_within_roi_only(self):
        profile = np.zeros(256)
        profile[12] = 10000
        profile[4] = 400
        profile[5] = 700
        idx, peak, is_delta = roi_peak(profile, np.arange(3, 8))
        self.assertEqual(idx, 5)
        self.assertEqual(peak, 700)
        self.assertFalse(is_delta)

    def test_reference_change_can_be_negative(self):
        baseline = np.full(256, 500.)
        sample = baseline.copy()
        sample[4] = 490
        sample[5] = 270
        sample[6] = 550
        idx, peak, is_delta = roi_peak(sample, np.arange(3, 8), baseline)
        self.assertEqual(idx, 5)
        self.assertEqual(peak, -230)
        self.assertTrue(is_delta)


class RecordingTests(unittest.TestCase):
    def test_csv_header_and_sidecar(self):
        class FakeVar:
            def __init__(self, value): self.value = value
            def get(self): return self.value
            def set(self, value): self.value = value
        class FakeWidget:
            def configure(self, **kwargs): pass
        with tempfile.TemporaryDirectory() as folder:
            app = App.__new__(App)
            app.args = SimpleNamespace(cfg=ROOT/'road_profile.cfg', log_dir=Path(folder))
            app.lines, app.bins, app.spacing, app.digest = config(app.args.cfg)
            app.adc_rate_hz = sampling_rate_hz(app.lines)
            app.indices = np.array([3,4,5,6])
            app.reference = None
            app.last_frame = time.monotonic()
            app.ground_truth = FakeVar('ice')
            app.csv_status = FakeVar('')
            app.log_btn = FakeWidget()
            app.ground_truth_combo = FakeWidget()
            app.csv_file = None
            app.csv_writer = None
            app.csv_frames = 0
            app.note = lambda message: None
            app.toggle_csv()
            self.assertIsNotNone(app.csv_writer)
            # One synthetic processed-profile record, not raw ADC data.
            app.csv_writer.writerow(['2026-10-26T12:00:00+00:00',1793016000.,8,'ice']+list(range(256)))
            app.csv_frames += 1
            path = app.csv_path
            app.stop_csv()
            with path.open(newline='') as handle:
                rows = list(csv.reader(handle))
            self.assertEqual(len(rows), 2)
            self.assertEqual(len(rows[0]), 260)
            self.assertEqual(rows[0][4], 'bin_000')
            self.assertEqual(rows[0][-1], 'bin_255')
            self.assertEqual(rows[1][-1], '255')
            meta = json.loads(path.with_suffix('.metadata.json').read_text())
            self.assertEqual(meta['adc_sample_rate_hz'], 12499000)
            self.assertEqual(meta['ground_truth_label'], 'ice')


if __name__ == '__main__':
    unittest.main()
