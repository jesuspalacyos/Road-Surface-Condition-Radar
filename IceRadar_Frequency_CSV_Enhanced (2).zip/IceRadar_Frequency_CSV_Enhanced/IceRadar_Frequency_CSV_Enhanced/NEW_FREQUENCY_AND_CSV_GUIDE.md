# IceRadar – new live beat-frequency plot and MATLAB data export

This is a modified copy of the original `ice_radar.py`. It preserves the SDK 3.x OOB UART decoder, firmware configuration, existing DRY/WET/ICE session-recording buttons, and existing experimental classifier. The code has **not been tested against physical AWR6843ISK hardware** in this environment.

## Installation, configuration and launch (Windows)

Open PowerShell in this folder:

```powershell
py -m pip install -r requirements.txt
py ice_radar.py --cli COM4 --data COM3
```

Use your *actual* Windows ports: CLI 115200 baud and DATA 921600 baud by default. Close TI Visualizer, terminal emulators, and any process holding either port. Requires **SDK 3.x xWR68xx Out-of-Box firmware** compatible with `road_profile.cfg`. The application does not flash firmware. Inspect `cli_log.txt` if the configuration fails.

## What's new in the window?

1. **Range plot:** same uncalibrated range-profile magnitudes, now with more vertical space for a second plot.
2. **Beat-frequency plot:** maps range-FFT bins onto the FMCW IF/beat-frequency axis: `f[k] = k*12499e3/256`. This is **not the transmitted 60 GHz RF spectrum** and is **not a fresh FFT of raw ADC data**; it relabels TI's already-computed range FFT using the correct sampling rate. The strongest return in the selected range ROI is marked with a vertical line.
3. **Capture DRY reference (5 s):** after confirming the known dry reference, captures at least 30 frames and makes the lower chart show `current_raw_bin - median(dry_raw_bin)` for each bin. This is exploratory **change detection**, not ice classification. Keep the radar position, surroundings, angle, substrate and distance fixed. The dry reference resets after reconnecting.
4. **Start/Stop CSV capture:** saves every received full 256-bin processed range profile plus UTC timestamp, radar frame count, and the selected known label (`unlabeled`, `dry`, `wet` or `ice`). The label control is locked during recording to avoid ambiguity. You can record multiple captures; each gets a distinct file.
5. **Metadata JSON alongside CSV:** stores configuration checksum, all configuration commands, FFT size, sampling rate, chirp slope, the chosen range ROI and (if already captured) the dry reference. The capture label represents human-supplied ground truth, **not** a radar prediction.
6. **Existing training:** the original experimental matcher remains unchanged. Collect at least three truly independent labeled sessions per class to train it. The new CSV captures do not automatically become classifier training samples.

Sample files saved by the program:

```
captures/
    radar_dry_20261026_202500_000001.csv
    radar_dry_20261026_202500_000001.metadata.json
```

The CSV format is `timestamp_utc,unix_time_s,frame,condition,bin_000,...,bin_255`. One row is one received radar frame. Stop capture before copying files. File size grows continuously as you record; use short, controlled test runs initially.

## Using MATLAB

1. Put `analyze_ice_captures.m` anywhere in your MATLAB path (or in this folder).
2. Run `analyze_ice_captures` and multi-select captures such as DRY, WET and ICE from the **same folder**. Keep each CSV's matching `.metadata.json` alongside it.
3. MATLAB will plot median range-FFT magnitude versus beat frequency, difference from a dry capture if provided, changes over time, and the same profile on the range axis. It also writes `radar_comparison.mat`.

MATLAB uses the exact ADC sample rate read from the saved metadata. To compare captures, all files must share FFT geometry and chosen ROI. If they do not match, the script stops rather than generating a misleading comparison.

## Why the 0.244 m bins matter

The existing profile uses 256 ADC samples, 12.499 Msamples/s, and 30 MHz/µs chirp slope. Its range-bin spacing is about **0.244 m**. That does not mean the radar can measure an ice layer's thickness; the return includes substrate, multipath, beam footprint, mounting angle, range and gain. An amplitude spike usually signifies a strong reflector at a range bin; it is **not an ice fingerprint**. A DRY/WET/ICE difference in a controlled experiment is only a candidate feature, and it may fail on new test specimens.

With the current **OOB UART TLV 2**, you can save processed FFT bins, but **not raw per-chirp complex ADC I/Q**. Capturing raw high-rate ADC through TI's standard workflow requires a supported capture interface (e.g. DCA1000EVM) and setup; simply adding Python plotting code does not produce raw ADC data. In some cases custom on-device firmware can compute and transmit engineered features, but UART bandwidth and available data limit what you can extract.

## Suggested controlled test

- Rigidly mount the board and target a sufficiently large patch of the **same substrate**. Record mounting height, slant range, incidence angle, ambient temperature and verified surface state outside the radar app.
- Capture 20–30 s each for known **DRY**, **WET**, and **ICE** using the *same* sensor location and configuration. Collect repeated preparations or days, not just consecutive clicks on the same sample.
- Use a *physical check* of the surface for labels. Do not label an ice cube held in front of asphalt as icy pavement.
- Compare within the same frequency/range ROI in MATLAB. Check whether the separation between ICE and WET persists across independent days and surfaces, and record the false positive and false negative rates.
- If the distributions overlap, modify sensing/experimental geometry or combine temperature with radar features before claiming ice detection. Do not just choose a favorable threshold from one session.

The application and plots are experimental: **do not use them to make road-safety decisions**.

## Software verification

The project includes synthetic unit tests (`test_core.py` and `test_frequency_export.py`). They test mathematical mapping, difference-peak selection and UART packet parsing. Neither tests physical connection nor proves ice sensitivity. Run:

```powershell
py -m unittest -v test_core test_frequency_export
```
