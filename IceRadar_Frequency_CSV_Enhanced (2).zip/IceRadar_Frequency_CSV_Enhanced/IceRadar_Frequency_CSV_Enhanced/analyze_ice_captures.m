%% Analyze saved AWR6843ISK processed range-FFT profiles
% Run in MATLAB. Select one or more *_*.csv files produced by ice_radar.py.
% Compare independently verified DRY, WET and ICE captures taken using the
% same radar mounting, substrate, distance and configuration.
%
% IMPORTANT: This is NOT an RF spectrum or raw ADC I/Q capture. The OOB
% UART TLV-2 is a processed, uncalibrated uint16 range FFT profile.
% The frequency axis is FMCW BEAT frequency, not the 60 GHz transmitter.
clear; close all; clc;

[filenames, folder] = uigetfile('*.csv', 'Select one or more radar CSV captures', 'MultiSelect', 'on');
if isequal(filenames, 0)
    disp('No files chosen.');
    return;
end
if ischar(filenames)
    filenames = {filenames};
end

captures = struct('file', {}, 'label', {}, 'time_s', {}, ...
    'profiles', {}, 'median_profile', {}, 'freq_mhz', {}, 'range_m', {}, ...
    'selected_indices', {});

for i = 1:numel(filenames)
    file = fullfile(folder, filenames{i});
    T = readtable(file);
    binCols = startsWith(T.Properties.VariableNames, 'bin_');
    A = double(T{:, binCols});
    if isempty(A)
        error('No bin_XXX columns in %s', filenames{i});
    end

    [~, basename] = fileparts(file);
    metaFile = fullfile(folder, [basename, '.metadata.json']);
    if ~isfile(metaFile)
        error('Missing metadata file for %s (needed for correct frequency axis).', filenames{i});
    end
    info = jsondecode(fileread(metaFile));
    nBins = size(A,2);
    if info.fft_bins ~= nBins
        error('FFT bin count mismatch in %s', filenames{i});
    end
    % In MATLAB, array indices start at 1, while exported bin IDs start at 0.
    fMHz = (0:nBins-1) .* double(info.adc_sample_rate_hz) ./ nBins ./ 1e6;
    ranges = (0:nBins-1) .* double(info.range_bin_spacing_m);
    idx = double(info.selected_range_indices(:))' + 1;
    idx = idx(idx >= 1 & idx <= nBins);
    if isempty(idx)
        error('No valid selected range bins in %s', filenames{i});
    end
    if i > 1
        if any(abs(captures(1).freq_mhz - fMHz) > 1e-9)
            error('Cannot compare captures with different ADC sampling rates / FFT sizes.');
        end
        if ~isequal(captures(1).selected_indices, idx)
            error('Cannot compare captures with different ROI indices.');
        end
    end
    label = string(info.ground_truth_label);
    time_s = double(T.unix_time_s);
    time_s = time_s - time_s(1);
    captures(i).file = filenames{i};
    captures(i).label = label;
    captures(i).time_s = time_s;
    captures(i).profiles = A;
    captures(i).median_profile = median(A,1);
    captures(i).freq_mhz = fMHz;
    captures(i).range_m = ranges;
    captures(i).selected_indices = idx;
    fprintf('%s | %s | %d frames | %.1f s\n', filenames{i}, label, size(A,1), time_s(end));
end

fMHz = captures(1).freq_mhz;
ranges = captures(1).range_m;
idx = captures(1).selected_indices;

%% Figure 1: comparison on the beat-frequency axis within the ROI
figure('Name', 'Radar profile comparison (beat frequency)');
hold on; grid on;
for i = 1:numel(captures)
    plot(fMHz(idx), captures(i).median_profile(idx), 'LineWidth', 1.6, ...
        'DisplayName', captures(i).label + " - " + string(captures(i).file));
end
xlabel('FMCW beat frequency (MHz), NOT transmitted RF frequency');
ylabel('Processed range-profile magnitude (raw firmware counts)');
title('Median amplitude per range-FFT bin, selected surface window');
legend('Location', 'best', 'Interpreter','none');

%% Figure 2: difference from DRY (only if dry capture is present)
labels = string({captures.label});
dryIdx = find(labels == "dry", 1, 'first');
if ~isempty(dryIdx)
    dryBaseline = captures(dryIdx).median_profile;
    figure('Name', 'Difference from dry reference');
    hold on; grid on;
    for i = 1:numel(captures)
        delta = captures(i).median_profile(idx) - dryBaseline(idx);
        plot(fMHz(idx), delta, 'LineWidth', 1.6, ...
            'DisplayName', captures(i).label + " - " + string(captures(i).file));
    end
    yline(0, '--');
    xlabel('FMCW beat frequency (MHz)');
    ylabel('Change from dry median (raw firmware counts)');
    title('Frequency-bin differences vs DRY (not a validated ice metric)');
    legend('Location','best', 'Interpreter','none');
else
    disp('No DRY capture found: skipping dry-referenced comparison plot.');
end

%% Figure 3: frame-to-frame stability of peak amplitude within ROI
figure('Name', 'Range-bin amplitude over time');
hold on; grid on;
for i = 1:numel(captures)
    topBin = max(captures(i).profiles(:, idx), [], 2);
    plot(captures(i).time_s, topBin, 'LineWidth', 1.1, ...
        'DisplayName', captures(i).label + " - " + string(captures(i).file));
end
xlabel('Time since recording started (s)');
ylabel('Peak ROI value (raw firmware counts)');
title('Temporal variation: motion or changing geometry can imitate surface changes');
legend('Location','best', 'Interpreter','none');

%% Figure 4: same original data in distance coordinates
figure('Name', 'Range profile comparison');
hold on; grid on;
for i = 1:numel(captures)
    plot(ranges(idx), captures(i).median_profile(idx), 'LineWidth', 1.6, ...
        'DisplayName', captures(i).label + " - " + string(captures(i).file));
end
xlabel('Radar slant range (m)');
ylabel('Processed range-profile magnitude (raw firmware counts)');
title('Same FFT bins plotted by distance instead of beat frequency');
legend('Location', 'best', 'Interpreter','none');

%% Export for further MATLAB experiments
matFile = fullfile(folder, 'radar_comparison.mat');
save(matFile, 'captures', '-v7.3');
fprintf('Saved all loaded captures into %s\n', matFile);
