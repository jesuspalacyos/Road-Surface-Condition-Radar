"""Experimental fixed-mount surface comparison for TI mmWave SDK 3.x OOB UART.
No pretrained ice detector. Range values remain in raw firmware units.
"""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import queue
import struct
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
import serial
from serial.tools import list_ports

MAGIC = bytes.fromhex('0201040306050807')
LABELS = ('dry', 'wet', 'ice')
ROOT = Path(__file__).resolve().parent


def config(path):
    raw = Path(path).read_bytes()
    lines = [s.split('%')[0].strip() for s in raw.decode('utf-8-sig').splitlines()]
    lines = [s for s in lines if s]
    p = next(s.split() for s in lines if s.startswith('profileCfg '))
    n = 1 << (int(p[10])-1).bit_length()
    spacing = 299792458 * float(p[11])*1000 / (2*float(p[8])*1e12*n)
    return lines, n, spacing, hashlib.sha256(raw).hexdigest()


def sampling_rate_hz(lines):
    """Read ADC sampling rate (ksps) from SDK 3.x profileCfg."""
    p = next(line.split() for line in lines if line.startswith('profileCfg '))
    return float(p[11]) * 1000.0


def beat_frequency_mhz(bins, sample_rate_hz):
    """Positive-frequency range-FFT bin centers, NOT transmitted RF frequency."""
    return np.arange(bins, dtype=float) * sample_rate_hz / bins / 1e6


def roi_peak(profile, indices, reference=None):
    """Largest |change| from a reference, otherwise strongest raw ROI bin.

    Amplitudes are uncalibrated firmware counts, not material-specific signatures.
    """
    data = np.asarray(profile, dtype=float)
    if reference is None:
        roi = data[indices]
        idx = int(indices[np.argmax(roi)])
        return idx, float(data[idx]), False
    difference = data - np.asarray(reference, dtype=float)
    idx = int(indices[np.argmax(np.abs(difference[indices]))])
    return idx, float(difference[idx]), True


class Decoder:
    def __init__(self, bins):
        self.buf = bytearray()
        self.bins = bins
        self.bad = 0

    def feed(self, data):
        self.buf.extend(data)
        out = []
        while True:
            i = self.buf.find(MAGIC)
            if i < 0:
                self.buf[:] = self.buf[-7:]
                break
            if i:
                del self.buf[:i]
            if len(self.buf) < 40:
                break
            version, size, platform, frame, cycles, objects, count, sub = struct.unpack_from('<8I', self.buf, 8)
            if size < 40 or size > 1048576 or count > 64:
                del self.buf[0]
                self.bad += 1
                continue
            if len(self.buf) < size:
                # Resynchronize if a corrupt length masks a subsequent complete packet.
                j = self.buf.find(MAGIC, 8)
                if j >= 0 and len(self.buf) >= j+40:
                    next_size = struct.unpack_from('<I', self.buf, j+12)[0]
                    if 40 <= next_size <= len(self.buf)-j:
                        del self.buf[:j]
                        self.bad += 1
                        continue
                break
            packet = bytes(self.buf[:size])
            del self.buf[:size]
            pos, profile, valid = 40, None, True
            for _ in range(count):
                if pos+8 > size:
                    valid = False
                    break
                typ, length = struct.unpack_from('<II', packet, pos)
                pos += 8
                # SDK 3.x OOB length excludes the 8-byte TLV header.
                if pos+length > size:
                    valid = False
                    break
                if typ == 2:
                    if length != self.bins*2:
                        valid = False
                        break
                    profile = np.frombuffer(packet, dtype='<u2', count=self.bins, offset=pos).astype(float)
                pos += length
            if valid and profile is not None and sub == 0:
                out.append((frame, profile))
            elif not valid:
                self.bad += 1
        return out


def fit(sessions):
    x = np.array([np.median(s['windows'], axis=0) for s in sessions])
    y = np.array([s['label'] for s in sessions])
    scale = np.maximum(np.std(x, axis=0), 32.0)
    centers = np.array([np.mean(x[y == k], axis=0) for k in LABELS])
    radii = []
    for k, c in zip(LABELS, centers):
        windows = np.concatenate([s['windows'] for s in sessions if s['label'] == k])
        d = np.sqrt(np.mean(((windows-c)/scale)**2, axis=1))
        radii.append(max(0.35, float(np.quantile(d, .95))*1.5))
    return centers, scale, np.array(radii)


def predict(model, x):
    centers, scale, radii = model
    d = np.sqrt(np.mean(((centers-x)/scale)**2, axis=1))
    order = np.argsort(d)
    k = order[0]
    margin = float((d[order[1]]-d[k])/max(d[order[1]], 1e-9))
    accepted = d[k] <= radii[k] and margin >= .25
    return LABELS[k] if accepted else 'unknown', margin


class App:
    def __init__(self, root, args):
        self.root, self.args = root, args
        self.lines, self.bins, self.spacing, self.digest = config(args.cfg)
        self.adc_rate_hz = sampling_rate_hz(self.lines)
        self.frequency_mhz = beat_frequency_mhz(self.bins, self.adc_rate_hz)
        self.events = queue.Queue(maxsize=1000)
        self.stop = threading.Event()
        self.worker = None
        self.sessions, self.model = [], None
        self.recording = None
        self.batch, self.window_start = [], time.monotonic()
        self.last_frame = 0
        self.meta = None
        self.history = []
        self.reference = None
        self.reference_state = None
        self.last_redraw = 0.0
        self.csv_file = None
        self.csv_writer = None
        self.csv_path = None
        self.csv_frames = 0
        root.title('AWR6843ISK • Experimental Ice Surface Comparison + Beat Frequency Logger')
        root.geometry('1120x920')
        frame = ttk.Frame(root, padding=16)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='Surface comparison lab', font=('Segoe UI', 20, 'bold')).pack(anchor='w')
        ttk.Label(frame, text='Experimental sample matching • No calibrated probability • Fixed mounting required').pack(anchor='w')
        controls = ttk.Frame(frame)
        controls.pack(fill='x', pady=14)
        self.cli, self.data = tk.StringVar(value=args.cli), tk.StringVar(value=args.data)
        ports = [p.device for p in list_ports.comports()]
        for title, var in [('CLI port', self.cli), ('DATA port', self.data)]:
            ttk.Label(controls, text=title).pack(side='left', padx=4)
            ttk.Combobox(controls, textvariable=var, values=ports, width=10).pack(side='left')
        self.lo, self.hi = tk.StringVar(value='0.5'), tk.StringVar(value='1.5')
        for title, var in [('Range min (m)', self.lo), ('max (m)', self.hi)]:
            ttk.Label(controls, text=title).pack(side='left', padx=4)
            ttk.Entry(controls, textvariable=var, width=6).pack(side='left')
        self.connect_btn = ttk.Button(controls, text='Connect', command=self.connect)
        self.connect_btn.pack(side='left', padx=10)
        self.result = tk.StringVar(value='NOT CALIBRATED')
        ttk.Label(frame, textvariable=self.result, font=('Segoe UI', 24, 'bold')).pack(anchor='w')
        self.status = tk.StringVar(value=f'Range-bin spacing: {self.spacing:.3f} m. Select ports and a range window around the surface.')
        ttk.Label(frame, textvariable=self.status, wraplength=900).pack(anchor='w', pady=8)
        ttk.Label(frame, text='Range profile (processed range FFT, raw firmware counts)').pack(anchor='w')
        self.canvas = tk.Canvas(frame, background='#101b2b', height=175, highlightthickness=0)
        self.canvas.pack(fill='x', pady=(3, 8))
        ttk.Label(frame, text='Beat-frequency axis / difference from captured DRY reference (not the 60 GHz RF spectrum)').pack(anchor='w')
        self.freq_canvas = tk.Canvas(frame, background='#101b2b', height=175, highlightthickness=0)
        self.freq_canvas.pack(fill='x', pady=(3, 8))
        analysis_controls = ttk.Frame(frame)
        analysis_controls.pack(fill='x', pady=(0, 8))
        ttk.Button(analysis_controls, text='Capture DRY reference (5 s)', command=self.capture_reference).pack(side='left', padx=4)
        self.peak_text = tk.StringVar(value='Peak: connect to view data. Reference is optional.')
        ttk.Label(analysis_controls, textvariable=self.peak_text).pack(side='left', padx=10)
        recording_controls = ttk.Frame(frame)
        recording_controls.pack(fill='x', pady=6)
        ttk.Label(recording_controls, text='Known test surface:').pack(side='left', padx=4)
        self.ground_truth = tk.StringVar(value='unlabeled')
        self.ground_truth_combo = ttk.Combobox(recording_controls, state='readonly', textvariable=self.ground_truth,
                                                values=('unlabeled', *LABELS), width=12)
        self.ground_truth_combo.pack(side='left', padx=4)
        self.log_btn = ttk.Button(recording_controls, text='Start CSV capture', command=self.toggle_csv)
        self.log_btn.pack(side='left', padx=8)
        self.csv_status = tk.StringVar(value='CSV capture off (exports every range bin, every received frame)')
        ttk.Label(recording_controls, textvariable=self.csv_status).pack(side='left', padx=6)
        buttons = ttk.Frame(frame)
        buttons.pack(fill='x', pady=12)
        for label in LABELS:
            ttk.Button(buttons, text=f'Record {label.upper()} (15 s)', command=lambda k=label:self.record(k)).pack(side='left', padx=4)
        ttk.Button(buttons, text='Build / validate model', command=self.train).pack(side='left', padx=8)
        self.counts = tk.StringVar(value='Record at least 3 independent sessions per surface; 5–10 recommended.')
        ttk.Label(frame, textvariable=self.counts).pack(anchor='w')
        self.log = tk.Text(frame, height=5, wrap='word')
        self.log.pack(fill='both', expand=True, pady=8)
        root.protocol('WM_DELETE_WINDOW', self.close)
        root.after(60, self.poll)

    def note(self, text):
        self.log.insert('end', text+'\n')
        self.log.see('end')

    def capture_reference(self):
        if not self.last_frame or time.monotonic()-self.last_frame > 2:
            messagebox.showinfo('Reference', 'Connect and wait for live radar frames first.')
            return
        if not messagebox.askokcancel('Capture dry reference',
                                      'The surface must be independently verified DRY.\n'
                                      'Keep the mounting, angle, distance and background fixed.\n'
                                      'Capture 5 seconds of DRY radar data?'):
            return
        self.reference_state = {'end': time.monotonic()+5.0, 'profiles': []}
        self.note('Capturing 5-second DRY reference. Do not move the sensor or target.')

    def toggle_csv(self):
        if self.csv_file is not None:
            self.stop_csv()
            return
        if not self.last_frame or time.monotonic()-self.last_frame > 2:
            messagebox.showinfo('CSV', 'Connect and wait for live radar frames first.')
            return
        try:
            self.args.log_dir.mkdir(parents=True, exist_ok=True)
            label = self.ground_truth.get()
            stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
            self.csv_path = self.args.log_dir / f'radar_{label}_{stamp}.csv'
            metadata = {
                'format': 'awr6843isk_sdk3_range_profile_csv_v1',
                'note': 'Radar-processed TLV type 2 range FFT profile; NOT raw ADC IQ or transmit RF spectrum',
                'timestamp_started_utc': datetime.now(timezone.utc).isoformat(),
                'ground_truth_label': label,
                'cfg_sha256': self.digest,
                'cfg_file': str(self.args.cfg),
                'configuration_commands': self.lines,
                'fft_bins': self.bins,
                'adc_sample_rate_hz': self.adc_rate_hz,
                'chirp_slope_mhz_per_us': float(next(x.split() for x in self.lines if x.startswith('profileCfg '))[8]),
                'frequency_axis': 'f_beat(bin_k) = k * adc_sample_rate_hz / fft_bins',
                'range_bin_spacing_m': self.spacing,
                'selected_range_indices': self.indices.tolist(),
                'dry_reference_raw_counts': self.reference.tolist() if self.reference is not None else None,
                'firmware_values': 'uncalibrated uint16 range-profile counts',
            }
            metadata_path = self.csv_path.with_suffix('.metadata.json')
            metadata_path.write_text(json.dumps(metadata, indent=2), encoding='utf-8')
            self.csv_file = self.csv_path.open('w', newline='', encoding='utf-8')
            self.csv_writer = csv.writer(self.csv_file)
            self.csv_writer.writerow(['timestamp_utc', 'unix_time_s', 'frame', 'condition']+
                                     [f'bin_{k:03d}' for k in range(self.bins)])
            self.csv_file.flush()
            self.csv_frames = 0
            self.log_btn.configure(text='Stop CSV capture')
            self.ground_truth_combo.configure(state='disabled')
            self.csv_status.set(f'Capturing {label} ... 0 frames')
            self.note('CSV started: '+str(self.csv_path))
        except Exception as exc:
            self.stop_csv()
            messagebox.showerror('CSV export', str(exc))

    def stop_csv(self):
        if self.csv_file is not None:
            self.csv_file.flush()
            self.csv_file.close()
            self.csv_file = None
            self.csv_writer = None
            self.note(f'CSV saved: {self.csv_path} ({self.csv_frames} frames).')
        self.log_btn.configure(text='Start CSV capture')
        self.ground_truth_combo.configure(state='readonly')
        self.csv_status.set(f'CSV capture off | last file: {self.csv_frames} frames')

    def connect(self):
        try:
            if self.worker and self.worker.is_alive():
                raise ValueError('Previous connection is still closing; retry in a moment.')
            self.stop.clear()
            self.model = None
            self.batch, self.history = [], []
            self.reference = None
            self.reference_state = None
            self.window_start = time.monotonic()
            if self.cli.get() == self.data.get():
                raise ValueError('CLI and DATA must be different ports.')
            lo, hi = float(self.lo.get()), float(self.hi.get())
            if not 0 < lo < hi <= (self.bins-1)*self.spacing:
                raise ValueError('Enter a valid positive range interval.')
            self.indices = np.where((np.arange(self.bins)*self.spacing >= lo)&(np.arange(self.bins)*self.spacing <= hi))[0]
            if len(self.indices) < 3:
                raise ValueError('Select at least 3 range bins (a wider range window).')
            self.meta = {'cfg_sha256':self.digest, 'bins':self.bins, 'indices':self.indices.tolist(), 'features':'median_raw_range_v1'}
            if self.args.samples.exists():
                saved = json.loads(self.args.samples.read_text())
                if saved['metadata'] != self.meta:
                    raise ValueError('Saved samples use a different configuration/range. Restore that range or use --samples new_samples.json.')
                self.sessions = saved['sessions']
                self.update_counts()
            self.connect_btn.config(state='disabled')
            self.worker = threading.Thread(target=self.acquire, args=(self.cli.get(), self.data.get()), daemon=True)
            self.worker.start()
        except Exception as e:
            messagebox.showerror('Connection', str(e))

    def acquire(self, cli_port, data_port):
        cli = data = None
        try:
            cli = serial.Serial(cli_port, 115200, timeout=.15, write_timeout=2)
            data = serial.Serial(data_port, self.args.baud, timeout=.1)
            decoder = Decoder(self.bins)
            with open(ROOT/'cli_log.txt', 'w', encoding='utf-8') as log:
                for line in self.lines:
                    if self.stop.is_set():
                        return
                    cli.reset_input_buffer()
                    cli.write((line+'\n').encode())
                    response = bytearray()
                    deadline = time.monotonic()+5
                    while time.monotonic() < deadline:
                        response.extend(cli.read(cli.in_waiting or 1))
                        if b'Done' in response or b'Error' in response or b'not recognized' in response:
                            break
                    answer = response.decode(errors='replace')
                    log.write(line+'\n'+answer+'\n')
                    log.flush()
                    if 'Done' not in answer or 'Error' in answer or 'not recognized' in answer:
                        raise RuntimeError(f'Configuration rejected/timed out at: {line}\n{answer}\nSee cli_log.txt; verify SDK 3.6 OOB firmware.')
            self.events.put(('note', 'Configuration accepted. Waiting for range-profile TLV 2.'))
            last = time.monotonic()
            while not self.stop.is_set():
                for item in decoder.feed(data.read(data.in_waiting or 1)):
                    last = time.monotonic()
                    try:
                        self.events.put_nowait(('frame', (item[0], item[1], time.time())))
                    except queue.Full:
                        raise RuntimeError('Display cannot keep up; recording stopped to avoid stale classification.')
                if time.monotonic()-last > 10:
                    raise RuntimeError(f'No valid range profile for 10 s. Check DATA port, baud and SDK OOB firmware. Malformed packets: {decoder.bad}')
        except Exception as e:
            self.events.put(('error', str(e)))
        finally:
            if cli:
                try:
                    cli.write(b'sensorStop\n')
                except Exception:
                    pass
                cli.close()
            if data:
                data.close()

    def update_counts(self):
        self.counts.set('Saved sessions: '+ ' | '.join(f'{k.upper()}: {sum(s["label"] == k for s in self.sessions)}' for k in LABELS))

    def record(self, label):
        if time.monotonic()-self.last_frame > 2 or not self.meta:
            messagebox.showinfo('Recording', 'Connect and wait for live data first.')
            return
        if self.recording:
            return
        if not messagebox.askokcancel('Confirm known surface', f'Is the surface actually {label.upper()}?\nUse independent ground truth, the same substrate, and the same mounting. Keep people and hands out of view during recording.'):
            return
        self.recording = {'label':label, 'started':time.time(), 'windows':[]}
        self.record_end = time.monotonic()+15
        self.batch = []
        self.window_start = time.monotonic()
        self.model = None
        self.result.set('RECORDING '+label.upper())

    def train(self):
        if self.recording:
            return
        if any(sum(s['label']==k for s in self.sessions)<3 for k in LABELS):
            messagebox.showinfo('More samples needed', 'Record at least 3 independent sessions for EACH of dry, wet and ice.')
            return
        matrix = {k:{p:0 for p in (*LABELS,'unknown')} for k in LABELS}
        for i, held in enumerate(self.sessions):
            model = fit(self.sessions[:i]+self.sessions[i+1:])
            for x in held['windows']:
                label, _ = predict(model, np.array(x))
                matrix[held['label']][label] += 1
        self.note('Leave-one-session-out results (held-out windows; not field accuracy):')
        for k, row in matrix.items():
            self.note(k.upper()+': '+str(row))
        report = {'method':'leave-one-session-out; all windows from held session excluded', 'counts':matrix,
                  'warning':'Same-mount lab check only. Adjacent windows are correlated. Validate on new days and specimens.'}
        self.args.samples.with_suffix('.validation.json').write_text(json.dumps(report, indent=2))
        self.model = fit(self.sessions)
        self.history = []
        self.note('Model built. UNKNOWN means ambiguous or outside sample envelope. Matching thresholds are heuristics.')

    @staticmethod
    def trace(canvas, values, x0, x1, y0, y1, min_value, max_value, color, width=2):
        if len(values) < 2:
            return
        span = max(float(max_value-min_value), 1.0)
        coords = []
        for i, v in enumerate(values):
            coords.extend((x0+i*(x1-x0)/(len(values)-1),
                           y1-(float(v)-min_value)/span*(y1-y0)))
        canvas.create_line(*coords, fill=color, width=width)

    def draw(self, profile):
        n = min(self.bins, max(20, int(self.indices[-1])+5))
        roi = self.indices
        idx, peak, is_delta = roi_peak(profile, roi, self.reference)
        freq = self.frequency_mhz[idx]
        rng = idx*self.spacing
        desc = f'{peak:+.0f} counts vs DRY' if is_delta else f'{peak:.0f} raw counts'
        self.peak_text.set(f'ROI strongest {"change" if is_delta else "bin"}: '
                           f'{freq:.3f} MHz / {rng:.2f} m / {desc} — NOT an ice diagnosis')
        for c in (self.canvas, self.freq_canvas):
            c.delete('all')
        w = max(self.canvas.winfo_width(), 600)
        h = 175
        x0, x1 = 50, w-20
        y0, y1 = 25, 143
        c = self.canvas
        values = profile[:n]
        low, high = float(values.min()), float(values.max())
        c.create_line(x0,y1,x1,y1,fill='#74889d')
        c.create_text(8,4,anchor='nw',fill='white',text=f'Range • counts [{low:.0f}–{high:.0f}] (auto scale)')
        for bound in (int(roi[0]), int(roi[-1])):
            x = x0 + bound*(x1-x0)/(n-1)
            c.create_line(x,y0,x,y1,fill='#f4cb70',dash=(4,4))
        self.trace(c, values, x0,x1,y0,y1,low,high,'#63ddd0')
        c.create_text(x0,151,anchor='w',fill='white',text=f'0 m  ·  slant range  ·  {(n-1)*self.spacing:.2f} m')
        c = self.freq_canvas
        c.create_line(x0,y1,x1,y1,fill='#74889d')
        if self.reference is None:
            low, high = float(values.min()), float(values.max())
            self.trace(c,values,x0,x1,y0,y1,low,high,'#5fd6ff')
            c.create_text(8,4,anchor='nw',fill='white',text='Beat-frequency spectrum • raw counts (capture DRY baseline for change plot)')
        else:
            difference = (profile-self.reference)[:n]
            span = max(float(np.max(np.abs(difference))), 1.0)
            self.trace(c,difference,x0,x1,y0,y1,-span,span,'#ffb567')
            y_zero = (y0+y1)/2
            c.create_line(x0,y_zero,x1,y_zero,fill='#7b8a94',dash=(4,4))
            c.create_text(8,4,anchor='nw',fill='white',text=f'Change relative to DRY reference • ±{span:.0f} raw counts')
        xpeak = x0 + idx*(x1-x0)/(n-1)
        c.create_line(xpeak,y0,xpeak,y1,fill='#ffdf80',dash=(2,3))
        for bound in (int(roi[0]), int(roi[-1])):
            x = x0 + bound*(x1-x0)/(n-1)
            c.create_line(x,y0,x,y1,fill='#f4cb70',dash=(4,4))
        c.create_text(x0,151,anchor='w',fill='white',
                      text=f'0 MHz  ·  processed beat frequency (not RF)  ·  {self.frequency_mhz[n-1]:.3f} MHz')

    def on_frame(self, item):
        frame, profile, received_epoch = item
        now = time.monotonic()
        self.last_frame = now
        if self.csv_writer is not None:
            self.csv_writer.writerow([datetime.fromtimestamp(received_epoch, timezone.utc).isoformat(),
                                      f'{received_epoch:.6f}', frame, self.ground_truth.get()]+
                                     [int(v) for v in profile])
            self.csv_frames += 1
            if self.csv_frames % 20 == 0:
                self.csv_file.flush()
                self.csv_status.set(f'Capturing {self.ground_truth.get()} ... {self.csv_frames} frames')
        if self.reference_state is not None:
            self.reference_state['profiles'].append(profile.copy())
            if now >= self.reference_state['end']:
                count = len(self.reference_state['profiles'])
                if count >= 30:
                    self.reference = np.median(np.stack(self.reference_state['profiles']), axis=0)
                    self.note(f'DRY reference acquired from {count} frames. Orange trace shows difference from dry.')
                else:
                    self.note(f'DRY reference discarded: only {count} valid frames (need >=30).')
                self.reference_state = None
        self.batch.append(profile[self.indices])
        if now-self.last_redraw >= .12:
            self.draw(profile)
            self.last_redraw = now
        self.status.set(f'Frame {frame} | Surface window: {self.indices[0]*self.spacing:.2f}–{self.indices[-1]*self.spacing:.2f} m | Receiving range data')
        if now-self.window_start < 1:
            return
        batch, self.batch = self.batch, []
        self.window_start = now
        if len(batch)<5:
            self.result.set('UNKNOWN — insufficient fresh frames')
            self.history = []
            return
        x = np.median(batch, axis=0)
        if self.recording:
            self.recording['windows'].append(x.tolist())
            self.result.set(f'RECORDING {self.recording["label"].upper()} — {max(0,int(self.record_end-now))} s')
            if now >= self.record_end:
                if len(self.recording['windows']) >= 10:
                    self.sessions.append(self.recording)
                    payload = {'metadata':self.meta,'sessions':self.sessions}
                    temp = self.args.samples.with_suffix('.tmp')
                    temp.write_text(json.dumps(payload))
                    temp.replace(self.args.samples)
                    self.note('Saved '+self.recording['label']+' session. Change/reprepare the sample before the next session.')
                else:
                    self.note('Discarded session: insufficient valid windows.')
                self.recording = None
                self.update_counts()
                self.result.set('Build model after recording all surfaces')
        elif self.model:
            label, margin = predict(self.model, x)
            self.history = (self.history+[label])[-3:]
            stable = len(self.history)==3 and len(set(self.history))==1
            result = label if stable else 'unknown'
            text = 'ICE-LIKE SAMPLE MATCH' if result=='ice' else result.upper()
            self.result.set(text)
        else:
            self.result.set('NOT CALIBRATED — record samples / build model')

    def poll(self):
        try:
            for _ in range(100):
                kind, payload = self.events.get_nowait()
                if kind=='frame':
                    self.on_frame(payload)
                elif kind=='error':
                    self.note('ERROR: '+payload)
                    self.result.set('DISCONNECTED / NO VALID DATA')
                    self.recording = None
                    self.reference_state = None
                    self.batch, self.history = [], []
                    self.last_frame = 0
                    if self.csv_file is not None:
                        self.stop_csv()
                    self.connect_btn.config(state='normal')
                else:
                    self.note(payload)
        except queue.Empty:
            pass
        except Exception as e:
            self.note('ERROR: '+str(e))
            self.recording = None
            self.stop.set()
        if self.last_frame and time.monotonic()-self.last_frame>2:
            self.result.set('UNKNOWN — stale data')
            self.recording = None
            self.reference_state = None
            self.batch, self.history = [], []
            if self.csv_file is not None:
                self.stop_csv()
        self.root.after(60, self.poll)

    def close(self):
        if self.csv_file is not None:
            self.stop_csv()
        self.stop.set()
        if self.worker:
            self.worker.join(timeout=1)
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cfg', type=Path, default=ROOT/'road_profile.cfg')
    parser.add_argument('--cli', default='COM4')
    parser.add_argument('--data', default='COM3')
    parser.add_argument('--baud', type=int, default=921600)
    parser.add_argument('--samples', type=Path, default=ROOT/'surface_samples.json')
    parser.add_argument('--log-dir', type=Path, default=ROOT/'captures',
                        help='Directory for full-frame CSV recordings and metadata')
    args = parser.parse_args()
    root = tk.Tk()
    App(root, args)
    root.mainloop()


if __name__ == '__main__':
    main()
